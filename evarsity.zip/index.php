<html>
<head>
	<title>Awesome Evarsity Scraper</title>
	<style>
		body {
			font-family: 'Verdana', 'Sans-serif';
		}
		.key {
			width: 150px;
			display: inline-block;
			font-weight: bold;
			margin-right: 10px;
			color: #2E8B57;
		}
		ul.details {
			width: 1000px;
			margin: 0 auto;
		}
		ul.details li {
			padding: 7px 20px;
			color: #228B22;
		}
		ul.details li:nth-child(even) {
			background-color: #F0F0F0;
		}
		ul.details li:nth-child(odd) {
			background-color: #F6F6F6;
		}		
	</style>
</head>
<body>

<?php
	include("scripts/srmerpApi.php");
	set_time_limit(30);

	$uname = $_GET['uname'];
	$password = $_GET['pass'];

	$obj = new evarsityAPI(array(
			'uname' => $uname,
			'pass' => $password
		));
	$ret = $obj->evarsityLogin();
	if(isset($ret["ERROR"])) {
		echo "<font color='#DC143C''>Couldn't connect to eVarsity Server</font> - Proabably down for maintainence";
	}

	if($obj->isLoggedIn) {
		echo "Logged in <br />";
		$stuInfoArray = $obj->fetchStudentInfo();
		?>
 		<h1>Welcome, <?php echo $stuInfoArray['name'];?><i> [<?php echo $stuInfoArray['register_no']; ?>] </i></h1>
		Your Details : <br />
		<?php
		echo "<ul class='details'>";
		foreach($stuInfoArray as $key => $temp) {
			echo "<li><span class='key'>".$key." : </span>  ".$temp."</li>";
		}
		echo "</ul>";
		$stuAttArray =  $obj->fetchStudentAttendance();
        echo "<ul class='details'>";
        foreach($stuAttArray as $key => $temp) {
            echo "<li><span class='key'>".$key." : </span>";
            foreach($temp as $t) {
                echo "<li style='margin-left: 50px'>".$t."</li>";
            }
            echo "</li>";
        }
        echo "</ul>";
	}
	else {
		echo "<br />Unable to log in <br />";
	}
?>


</body>
</html>